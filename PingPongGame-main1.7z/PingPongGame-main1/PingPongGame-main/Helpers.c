/*
 * Helpers.c
 *
 * Created: 26.09.2023 15:35:18
 *  Author: jannemli
 */ 
