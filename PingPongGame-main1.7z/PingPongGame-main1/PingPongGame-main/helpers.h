/*
 * helpers.h
 *
 * Created: 26.09.2023 15:38:38
 *  Author: jannemli
 */ 
enum PageEnum {
	MainPage,
	PlayPage,
	SettingsPage
};