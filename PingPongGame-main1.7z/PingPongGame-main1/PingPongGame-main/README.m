PE0 => Left button (MultiFn board)

PE2 => Right button (MultiFn board)

PD4 => Clock for ADC chip (PWM)

PD2 => Confirm button (MultiFn board)
