#include <stdio.h>
#include <stdlib.h>
#include <avr/io.h>
#include <avr/interrupt.h>

void SRAM_test(void);
void SRAM_init();
void INTERRUPT_init();