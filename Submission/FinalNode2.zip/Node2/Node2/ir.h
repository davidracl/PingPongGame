#include  <stdio.h>
#include "sam.h"

void ir_init(void);
int ir_read_value(void);
uint8_t ir_count_score();