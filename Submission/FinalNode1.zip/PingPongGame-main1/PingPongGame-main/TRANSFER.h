#include "ADC.h"
#include "CAN.h"
#include "OLED.h"

uint8_t motor_speed;
uint8_t servo_speed;

void transfer_joystick_position(struct joystickPosition* joystickPosition);
void transfer_touch_button();
uint8_t motor_get_speed();
uint8_t servo_get_speed();