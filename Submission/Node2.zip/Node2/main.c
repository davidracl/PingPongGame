/*
 * NODE2.c
 *
 * Created: 09.10.2023 08:28:03
 * Author : klevisr
 */ 

#include <stdarg.h>
#include "sam.h"
#include "can_controller.h"
#include "can_interrupt.h"
#include "uart.h"
#include "servo.h"
#include "motor.h"
#include "solenoid.h"

#define F_CPU 84000000

uint8_t FlagBallDetected;
uint8_t score;


int main ( void ) {
	
	// Initialize all
	SystemInit();
	uart_init(F_CPU, 115200);		// Initialize UART with baud rate 115200
	servo_init();
	ir_init();
	motor_init();
	solenoid_init();
	
	// Setup baud rate for CAN transmission
	// Baud rate: BRP = 20, SJW= 3, PRPAG= 1, PHASE1 = 5, PHASE2 = 6
	// equivalent to baud rate of 250 kbit/s
	can_init_def_tx_rx_mb(0x00143156);

	// Example message
	struct CAN_Message score_message;
	score_message.id = 98;
	score_message.data_length = 1;
	
	while(1)
	{
		// Receive CAN messages and handle 
		CAN0_Handler();
		
		// If Ball out of bounds: increase score
		if (FlagBallDetected){
			score = ir_count_score();
			
			// Send CAN message with score
			score_message.data[0] = score;
			can_send(&score_message, 0);
			delay_micros(1000);
			FlagBallDetected = 0;
			
		}
	}
	
}

volatile int read_adc_cdr;

// Interrupt Handler for IR
void ADC_Handler() {
	read_adc_cdr = ADC->ADC_CDR[7];
	FlagBallDetected = 1;
	ADC->ADC_ISR;		// Disable interrupt
}


