#include "ADC.h"
#include "CAN.h"
#include "OLED.h"

void transfer_joystick_position(struct joystickPosition* joystickPosition);
void transfer_touch_button();