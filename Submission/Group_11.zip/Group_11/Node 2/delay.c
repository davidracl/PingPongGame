/*
 * delay.c
 *
 * Author: Janne List
 * Date: 17 October 2023
 */

#include "delay.h"

void delay_micros(uint32_t us){
	uint32_t i;
	for(i = 0; i < 84*us; i++){
		__asm("nop");
	}
}

void delay_ms(uint32_t ms){
	delay_micros(ms * 1000);
}
