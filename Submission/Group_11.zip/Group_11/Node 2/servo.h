#include  <stdio.h>
#include "sam.h"

uint8_t currentAngle;
uint8_t servo_speed;

void servo_init();
void servo_set_angle(int angleDeg);
void move_servo(char joystick_position);
void servo_set_speed(uint8_t speed);