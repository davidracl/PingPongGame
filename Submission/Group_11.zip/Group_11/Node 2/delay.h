
#ifndef DELAY_H_
#define DELAY_H_

#include <inttypes.h>

void delay_micros(uint32_t us);
void delay_ms(uint32_t ms);

#endif
