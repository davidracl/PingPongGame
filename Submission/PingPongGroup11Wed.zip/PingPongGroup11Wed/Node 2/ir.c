#include "ir.h"

void ir_init(){
	PMC->PMC_PCER1 |= PMC_PCER1_PID37;  // ADC power on
	ADC->ADC_CR = ADC_CR_SWRST;			// Reset ADC
	
	ADC->ADC_MR |=  ADC_MR_TRGEN | ADC_MR_TRGSEL_ADC_TRIG1 | ADC_MR_SLEEP_NORMAL | ADC_MR_FREERUN_ON;	// Initialize ADC timer settings
	 
	
	ADC->ADC_EMR |= ADC_EMR_CMPSEL(7)	// enable comparison only for channel 7
				| ADC_EMR_CMPMODE_LOW;	// mode LOW (Generates an event when the converted data is lower than the low threshold of the window)
	
	ADC->ADC_CWR = ADC_CWR_LOWTHRES(1500);	// Set threshold to 1500 (if lower => interrupt)
	
	ADC->ADC_CHER |= ADC_CHER_CH7;		// enable channel
	
	// Enable comparison interrupt
	ADC->ADC_IER |= ADC_IER_COMPE;		
	NVIC_EnableIRQ(ADC_IRQn);
	NVIC_SetPriority(ADC_IRQn, 3);
	
	Score = 0;							// Initialize Score to zero
}

int ir_read_value(){
	return ADC->ADC_CDR[7];
}

uint8_t ir_count_score( ){
	Score ++;
	printf("Score: %u\r\n", Score);	
	return Score;
}