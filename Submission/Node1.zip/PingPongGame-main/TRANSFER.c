#include "TRANSFER.h"

// Send joystick Position via CAN with ID 100
void transfer_joystick_position(struct joystickPosition* joystickPosition){
	if (GameStarted){
		struct CAN_Message joystick_message;
		joystick_message.ID = 100;		// Joystick Position: ID 100
		joystick_message.data[0] = (uint8_t)joystickPosition->position;
		joystick_message.length = 1;
		
		can_send(&joystick_message);	// send message
	}
	
}

// Send touch button pressed via CAN with ID 99
void transfer_touch_button(){
	if (GameStarted){
		struct CAN_Message touch_button;
		touch_button.ID = 99;		// Touch button: ID 99
		touch_button.data[0] = 1;
		touch_button.length = 1;
	
		can_send(&touch_button);	// send message
	}
}

// Send Motor speed multiplier (ID: 98)
void transfer_motor_speed(uint8_t speed){
	printf("Send motor speed \r\n");
	struct CAN_Message motor_speed;
	motor_speed.ID = 98;		
	motor_speed.data[0] = speed;
	motor_speed.length = 1;
	
	can_send(&motor_speed);	// send message
}

// Send Servo Speed (ID: 97)
void transfer_servo_speed(uint8_t speed){
	printf("Send servo speed \r\n");
	struct CAN_Message servo_speed;
	servo_speed.ID = 97;		
	servo_speed.data[0] = speed;
	servo_speed.length = 1;
	
	can_send(&servo_speed);	// send message
}