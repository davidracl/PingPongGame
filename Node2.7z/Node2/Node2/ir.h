#include  <stdio.h>
#include "sam.h"

uint32_t Score;

void ir_init(void);
int ir_read_value(void);
void ir_count_score();