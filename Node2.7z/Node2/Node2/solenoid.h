#include  <stdio.h>
#include "sam.h"

void solenoid_init();
void solenoid_control();